-- MySQL Backup
-- Date: 2026-01-13 01:20:58
-- Type: manual

DROP TABLE IF EXISTS `balasan_komunikasis`;
CREATE TABLE `balasan_komunikasis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `komunikasi_id` bigint(20) unsigned NOT NULL,
  `pengirim_id` bigint(20) unsigned NOT NULL,
  `isi_balasan` text NOT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `balasan_komunikasis_komunikasi_id_foreign` (`komunikasi_id`),
  KEY `balasan_komunikasis_pengirim_id_foreign` (`pengirim_id`),
  CONSTRAINT `balasan_komunikasis_komunikasi_id_foreign` FOREIGN KEY (`komunikasi_id`) REFERENCES `komunikasi_ortus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `balasan_komunikasis_pengirim_id_foreign` FOREIGN KEY (`pengirim_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `bimbingan_konselings`;
CREATE TABLE `bimbingan_konselings` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned NOT NULL,
  `guru_id` bigint(20) unsigned NOT NULL,
  `kategori` enum('pribadi','sosial','belajar','karir') NOT NULL,
  `catatan` text DEFAULT NULL,
  `tanggal` date NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bimbingan_konselings_siswa_id_foreign` (`siswa_id`),
  KEY `bimbingan_konselings_guru_id_foreign` (`guru_id`),
  CONSTRAINT `bimbingan_konselings_guru_id_foreign` FOREIGN KEY (`guru_id`) REFERENCES `gurus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bimbingan_konselings_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `biodata_ortus`;
CREATE TABLE `biodata_ortus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `siswa_id` bigint(20) unsigned NOT NULL,
  `nama_ayah` varchar(255) DEFAULT NULL,
  `telp_ayah` varchar(15) DEFAULT NULL,
  `nama_ibu` varchar(255) DEFAULT NULL,
  `telp_ibu` varchar(15) DEFAULT NULL,
  `nama_wali` varchar(255) DEFAULT NULL,
  `telp_wali` varchar(15) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `foto_kk` varchar(255) NOT NULL,
  `status_approval` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `biodata_ortus_user_id_foreign` (`user_id`),
  KEY `biodata_ortus_siswa_id_foreign` (`siswa_id`),
  KEY `biodata_ortus_approved_by_foreign` (`approved_by`),
  CONSTRAINT `biodata_ortus_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `biodata_ortus_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `biodata_ortus_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `biodata_ortus` VALUES ('1', '6', '9', 'jamal', '08828324328428', 'yeni aeni', '08523391273324', NULL, NULL, 'xxxxxx', 'biodata_ortu/kk/9EsQBcIeoHULsilkwnR5pGFCCd7ay7kXhwaXbIfb.jpg', 'approved', NULL, '1', '2026-01-12 17:30:48', '2026-01-12 17:30:25', '2026-01-12 17:30:48');

DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `class_homeroom_teachers`;
CREATE TABLE `class_homeroom_teachers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `kelas_id` bigint(20) unsigned NOT NULL,
  `tahun_ajaran_id` bigint(20) unsigned NOT NULL,
  `assigned_by` bigint(20) unsigned NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_class_year` (`kelas_id`,`tahun_ajaran_id`),
  KEY `class_homeroom_teachers_tahun_ajaran_id_foreign` (`tahun_ajaran_id`),
  KEY `class_homeroom_teachers_assigned_by_foreign` (`assigned_by`),
  KEY `class_homeroom_teachers_user_id_tahun_ajaran_id_index` (`user_id`,`tahun_ajaran_id`),
  CONSTRAINT `class_homeroom_teachers_assigned_by_foreign` FOREIGN KEY (`assigned_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_homeroom_teachers_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_homeroom_teachers_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajarans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `class_homeroom_teachers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `gurus`;
CREATE TABLE `gurus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` bigint(20) unsigned NOT NULL,
  `nip` varchar(20) NOT NULL,
  `nama_guru` varchar(255) NOT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `bidang_studi` varchar(255) DEFAULT NULL,
  `mata_pelajaran` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`mata_pelajaran`)),
  `status` enum('aktif','tidak_aktif') NOT NULL DEFAULT 'aktif',
  `status_approval` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `gurus_nip_unique` (`nip`),
  KEY `gurus_users_id_foreign` (`users_id`),
  CONSTRAINT `gurus_users_id_foreign` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `gurus` VALUES ('1', '8', '198501012010011001', 'Budi Santoso', NULL, 'Matematika', NULL, 'aktif', 'pending', '2026-01-12 16:57:55', '2026-01-12 16:57:55');
INSERT INTO `gurus` VALUES ('2', '9', '198602022010012001', 'Siti Aminah', NULL, 'Bahasa Indonesia', NULL, 'aktif', 'pending', '2026-01-12 16:57:56', '2026-01-12 16:57:56');
INSERT INTO `gurus` VALUES ('3', '10', '198703032010011002', 'Ahmad Fauzi', NULL, 'Bahasa Inggris', NULL, 'aktif', 'pending', '2026-01-12 16:57:57', '2026-01-12 16:57:57');
INSERT INTO `gurus` VALUES ('4', '11', '198804042010012002', 'Dewi Lestari', NULL, 'Pemrograman', NULL, 'aktif', 'pending', '2026-01-12 16:57:57', '2026-01-12 16:57:57');
INSERT INTO `gurus` VALUES ('5', '12', '198905052010011003', 'Rizki Ramadhan', NULL, 'Jaringan Komputer', NULL, 'aktif', 'pending', '2026-01-12 16:57:58', '2026-01-12 16:57:58');
INSERT INTO `gurus` VALUES ('6', '4', 'AUTO-4-20260112', 'Randy orton', NULL, 'Bimbingan Konseling (BK)', NULL, 'aktif', 'approved', '2026-01-12 17:11:27', '2026-01-12 17:11:27');
INSERT INTO `gurus` VALUES ('7', '5', 'AUTO-5-20260112', 'Diallo caranstias', NULL, 'Umum', NULL, 'aktif', 'approved', '2026-01-12 17:11:27', '2026-01-12 17:11:27');

DROP TABLE IF EXISTS `jenis_pelanggarans`;
CREATE TABLE `jenis_pelanggarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(100) NOT NULL,
  `kategori` enum('ketertiban','kehadiran','pakaian','sikap','akademik','fasilitas','kriminal') NOT NULL,
  `nama_pelanggaran` varchar(255) NOT NULL,
  `poin` int(11) NOT NULL,
  `sanksi_rekomendasi` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `jenis_pelanggarans` VALUES ('1', 'ringan', 'ketertiban', 'Terlambat masuk kelas', '2', 'Teguran lisan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('2', 'ringan', 'ketertiban', 'Tidak mengikuti upacara bendera', '5', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('3', 'sedang', 'ketertiban', 'Membuat keributan di kelas', '10', 'Panggilan orang tua', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('4', 'sedang', 'kehadiran', 'Tidak mengikuti kegiatan belajar (membolos)', '15', 'Skorsing 1 hari', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('5', 'ringan', 'ketertiban', 'Keluar kelas tanpa izin saat pelajaran', '6', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('6', 'ringan', 'akademik', 'Tidur saat pelajaran berlangsung', '5', 'Teguran lisan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('7', 'sedang', 'akademik', 'Tidak mengerjakan tugas berulang kali', '8', 'Panggilan orang tua', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('8', 'ringan', 'sikap', 'Mengganggu teman saat belajar', '7', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('9', 'sedang', 'kehadiran', 'Tidak masuk tanpa keterangan', '10', 'Panggilan orang tua', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('10', 'sedang', 'ketertiban', 'Pulang sebelum waktunya tanpa izin', '10', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('11', 'ringan', 'pakaian', 'Seragam tidak dimasukkan', '3', 'Teguran lisan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('12', 'ringan', 'pakaian', 'Tidak memakai ikat pinggang', '3', 'Teguran lisan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('13', 'ringan', 'pakaian', 'Tidak memakai kaos kaki', '3', 'Teguran lisan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('14', 'ringan', 'pakaian', 'Memakai sepatu tidak sesuai ketentuan', '5', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('15', 'ringan', 'pakaian', 'Seragam tidak lengkap/tidak sesuai', '5', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('16', 'sedang', 'pakaian', 'Rambut tidak rapi (putra)', '8', 'Potong rambut', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('17', 'sedang', 'pakaian', 'Rambut dicat/diwarnai', '15', 'Panggilan orang tua + cat hitam', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('18', 'ringan', 'pakaian', 'Memakai aksesoris berlebihan', '5', 'Disita + teguran', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('19', 'sedang', 'pakaian', 'Rok terlalu pendek (putri)', '8', 'Ganti seragam', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('20', 'sedang', 'pakaian', 'Celana terlalu ketat/pensil', '8', 'Ganti seragam', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('21', 'ringan', 'pakaian', 'Memakai make up berlebihan', '5', 'Hapus + teguran', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('22', 'ringan', 'pakaian', 'Kuku panjang/dicat', '3', 'Potong kuku', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('23', 'ringan', 'pakaian', 'Memakai tindik berlebihan', '5', 'Lepas + teguran', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('24', 'ringan', 'pakaian', 'Memakai kaos dalam berwarna', '3', 'Teguran lisan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('25', 'ringan', 'pakaian', 'Tidak memakai dasi/badge', '3', 'Teguran lisan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('26', 'berat', 'kriminal', 'Merokok di lingkungan sekolah', '25', 'Skorsing 3 hari', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('27', 'berat', 'kriminal', 'Membawa rokok ke sekolah', '20', 'Disita + panggilan ortu', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('28', 'berat', 'sikap', 'Berkelahi dengan teman', '30', 'Skorsing 5 hari', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('29', 'sangat_berat', 'sikap', 'Berkelahi dengan siswa sekolah lain', '50', 'Skorsing 1 minggu', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('30', 'berat', 'kriminal', 'Membawa senjata tajam', '40', 'Disita + skorsing', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('31', 'sangat_berat', 'kriminal', 'Mengancam teman/guru', '50', 'Skorsing + lapor polisi', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('32', 'berat', 'kriminal', 'Mencuri barang milik sekolah/teman', '40', 'Ganti rugi + skorsing', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('33', 'berat', 'fasilitas', 'Merusak fasilitas sekolah', '35', 'Ganti rugi + skorsing', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('34', 'sangat_berat', 'kriminal', 'Membawa/menggunakan narkoba', '100', 'Dikeluarkan + lapor polisi', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('35', 'sangat_berat', 'kriminal', 'Membawa minuman keras', '75', 'Skorsing 2 minggu', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('36', 'berat', 'kriminal', 'Berjudi di lingkungan sekolah', '40', 'Skorsing 1 minggu', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('37', 'sangat_berat', 'kriminal', 'Melakukan tindakan asusila', '100', 'Dikeluarkan', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('38', 'sangat_berat', 'kriminal', 'Membawa konten pornografi', '50', 'Disita + skorsing', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('39', 'berat', 'akademik', 'Memalsukan tanda tangan/surat', '30', 'Skorsing 3 hari', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('40', 'berat', 'akademik', 'Menyontek saat ujian', '20', 'Nilai 0 + teguran', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('41', 'sedang', 'sikap', 'Berkata kasar kepada teman', '10', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('42', 'berat', 'sikap', 'Berkata kasar kepada guru', '25', 'Skorsing 3 hari', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('43', 'sedang', 'sikap', 'Tidak sopan kepada guru/karyawan', '15', 'Panggilan orang tua', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('44', 'berat', 'sikap', 'Membully teman', '35', 'Skorsing + konseling', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('45', 'berat', 'sikap', 'Menyebarkan hoax/fitnah', '30', 'Klarifikasi + skorsing', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('46', 'berat', 'sikap', 'Menghasut teman untuk berbuat negatif', '25', 'Skorsing 3 hari', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('47', 'sedang', 'ketertiban', 'Tidak mengikuti tata tertib sekolah', '10', 'Teguran tertulis', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('48', 'sedang', 'ketertiban', 'Membawa HP saat pelajaran berlangsung', '15', 'Disita 1 minggu', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('49', 'sedang', 'akademik', 'Main game saat pelajaran', '12', 'Disita HP + teguran', NULL, NULL);
INSERT INTO `jenis_pelanggarans` VALUES ('50', 'ringan', 'ketertiban', 'Membuat kegaduhan di perpustakaan', '8', 'Teguran tertulis', NULL, NULL);

DROP TABLE IF EXISTS `jenis_prestasis`;
CREATE TABLE `jenis_prestasis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `kelompok` varchar(100) DEFAULT NULL,
  `nama_prestasi` varchar(255) NOT NULL,
  `poin_reward` int(11) NOT NULL DEFAULT 0,
  `poin` int(11) DEFAULT 0,
  `kategori` varchar(50) DEFAULT NULL,
  `tingkat` varchar(50) DEFAULT NULL,
  `penghargaan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `jenis_prestasis` VALUES ('1', NULL, 'Juara 1 Olimpiade Matematika Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('2', NULL, 'Juara 2 Olimpiade Matematika Tingkat Kota', '40', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('3', NULL, 'Juara 3 Olimpiade Matematika Tingkat Kota', '30', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('4', NULL, 'Juara 1 Olimpiade Fisika Tingkat Provinsi', '70', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('5', NULL, 'Juara 1 Olimpiade Kimia Tingkat Sekolah', '25', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('6', NULL, 'Juara 1 Olimpiade Biologi Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('7', NULL, 'Juara 1 Lomba Karya Tulis Ilmiah Tingkat Nasional', '80', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('8', NULL, 'Juara 2 Lomba Karya Tulis Ilmiah Tingkat Provinsi', '60', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('9', NULL, 'Juara 1 Lomba Debat Bahasa Inggris Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('10', NULL, 'Juara 1 Lomba Cerdas Cermat Tingkat Kota', '45', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('11', NULL, 'Ranking 1 Kelas', '20', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('12', NULL, 'Ranking 2 Kelas', '15', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('13', NULL, 'Ranking 3 Kelas', '10', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('14', NULL, 'Nilai Sempurna Ujian Nasional', '30', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('15', NULL, 'Lulus Sertifikasi Bahasa Inggris (TOEFL/IELTS)', '35', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('16', NULL, 'Juara 1 Sepak Bola Tingkat Provinsi', '70', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('17', NULL, 'Juara 2 Sepak Bola Tingkat Kota', '45', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('18', NULL, 'Juara 1 Basket Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('19', NULL, 'Juara 1 Voli Tingkat Sekolah', '25', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('20', NULL, 'Juara 1 Bulu Tangkis Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('21', NULL, 'Juara 1 Atletik Lari 100m Tingkat Provinsi', '65', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('22', NULL, 'Juara 1 Renang Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('23', NULL, 'Juara 1 Pencak Silat Tingkat Nasional', '80', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('24', NULL, 'Juara 2 Pencak Silat Tingkat Provinsi', '60', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('25', NULL, 'Juara 1 Karate Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('26', NULL, 'Juara 1 Taekwondo Tingkat Provinsi', '65', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('27', NULL, 'Juara 1 Tenis Meja Tingkat Kota', '45', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('28', NULL, 'Juara 1 Futsal Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('29', NULL, 'Juara 1 Catur Tingkat Provinsi', '60', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('30', NULL, 'Best Player Turnamen Olahraga', '40', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('31', NULL, 'Juara 1 Lomba Menyanyi Tingkat Nasional', '75', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('32', NULL, 'Juara 1 Lomba Tari Tradisional Tingkat Provinsi', '65', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('33', NULL, 'Juara 1 Lomba Band Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('34', NULL, 'Juara 1 Lomba Melukis Tingkat Kota', '45', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('35', NULL, 'Juara 1 Lomba Fotografi Tingkat Provinsi', '60', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('36', NULL, 'Juara 1 Lomba Desain Grafis Tingkat Nasional', '80', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('37', NULL, 'Juara 1 Lomba Puisi Tingkat Kota', '45', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('38', NULL, 'Juara 1 Lomba Teater Tingkat Provinsi', '65', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('39', NULL, 'Juara 1 Lomba Kaligrafi Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('40', NULL, 'Juara 1 Lomba Musik Tradisional Tingkat Provinsi', '60', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('41', NULL, 'Juara 1 Lomba Robotika Tingkat Nasional', '85', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('42', NULL, 'Juara 1 Lomba Programming Tingkat Provinsi', '70', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('43', NULL, 'Juara 1 Lomba Web Design Tingkat Kota', '55', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('44', NULL, 'Juara 1 Lomba Inovasi Teknologi Tingkat Nasional', '90', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('45', NULL, 'Juara 1 Lomba Game Development Tingkat Provinsi', '70', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('46', NULL, 'Juara 1 MTQ Tingkat Provinsi', '65', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('47', NULL, 'Juara 1 Lomba Dai Muda Tingkat Kota', '50', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('48', NULL, 'Juara 1 Lomba Hafalan Al-Quran Tingkat Provinsi', '70', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('49', NULL, 'Relawan Terbaik Kegiatan Sosial', '35', '0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `jenis_prestasis` VALUES ('50', NULL, 'Duta Anti Narkoba Tingkat Kota', '45', '0', NULL, NULL, NULL, NULL, NULL);

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `kelas`;
CREATE TABLE `kelas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama_kelas` varchar(255) NOT NULL,
  `jurusan` varchar(255) DEFAULT NULL,
  `wali_kelas_id` bigint(20) unsigned DEFAULT NULL,
  `tahun_ajaran_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `kelas_wali_kelas_id_foreign` (`wali_kelas_id`),
  KEY `kelas_tahun_ajaran_id_foreign` (`tahun_ajaran_id`),
  CONSTRAINT `kelas_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajarans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `kelas_wali_kelas_id_foreign` FOREIGN KEY (`wali_kelas_id`) REFERENCES `gurus` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `kelas` VALUES ('1', 'X PPLG', 'PPLG', '1', '2', '2026-01-12 16:57:40', '2026-01-12 17:11:28');
INSERT INTO `kelas` VALUES ('2', 'X BDP', 'BDP', '2', '2', '2026-01-12 16:57:40', '2026-01-12 17:11:29');
INSERT INTO `kelas` VALUES ('3', 'X AKT', 'AKT', '3', '2', '2026-01-12 16:57:40', '2026-01-12 17:11:30');
INSERT INTO `kelas` VALUES ('4', 'X DKV', 'DKV', '4', '2', '2026-01-12 16:57:40', '2026-01-12 17:11:31');
INSERT INTO `kelas` VALUES ('5', 'X ANM', 'ANM', '5', '2', '2026-01-12 16:57:40', '2026-01-12 17:11:31');
INSERT INTO `kelas` VALUES ('6', 'XI PPLG', 'PPLG', '6', '2', '2026-01-12 16:57:40', '2026-01-12 17:11:31');
INSERT INTO `kelas` VALUES ('7', 'XI BDP', 'BDP', '7', '2', '2026-01-12 16:57:40', '2026-01-12 17:11:31');
INSERT INTO `kelas` VALUES ('8', 'XI AKT', 'AKT', '1', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');
INSERT INTO `kelas` VALUES ('9', 'XI DKV', 'DKV', '2', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');
INSERT INTO `kelas` VALUES ('10', 'XI ANM', 'ANM', '3', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');
INSERT INTO `kelas` VALUES ('11', 'XII PPLG', 'PPLG', '4', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');
INSERT INTO `kelas` VALUES ('12', 'XII BDP', 'BDP', '5', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');
INSERT INTO `kelas` VALUES ('13', 'XII AKT', 'AKT', '6', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');
INSERT INTO `kelas` VALUES ('14', 'XII DKV', 'DKV', '7', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');
INSERT INTO `kelas` VALUES ('15', 'XII ANM', 'ANM', '1', '2', '2026-01-12 16:57:41', '2026-01-12 17:11:32');

DROP TABLE IF EXISTS `komunikasi_ortus`;
CREATE TABLE `komunikasi_ortus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned NOT NULL,
  `pengirim_id` bigint(20) unsigned NOT NULL,
  `penerima_id` bigint(20) unsigned NOT NULL,
  `jenis` enum('pesan','laporan_pembinaan','panggilan_ortu','konsultasi') NOT NULL,
  `subjek` varchar(255) NOT NULL,
  `isi_pesan` text NOT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `status` enum('terkirim','dibaca','dibalas') NOT NULL DEFAULT 'terkirim',
  `dibaca_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `komunikasi_ortus_siswa_id_foreign` (`siswa_id`),
  KEY `komunikasi_ortus_pengirim_id_foreign` (`pengirim_id`),
  KEY `komunikasi_ortus_penerima_id_foreign` (`penerima_id`),
  CONSTRAINT `komunikasi_ortus_penerima_id_foreign` FOREIGN KEY (`penerima_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `komunikasi_ortus_pengirim_id_foreign` FOREIGN KEY (`pengirim_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `komunikasi_ortus_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES ('58', '0001_01_01_000000_create_users_table', '1');
INSERT INTO `migrations` VALUES ('59', '0001_01_01_000001_create_cache_table', '1');
INSERT INTO `migrations` VALUES ('60', '0001_01_01_000002_create_jobs_table', '1');
INSERT INTO `migrations` VALUES ('61', '2024_01_01_000000_create_tahun_ajarans_table', '1');
INSERT INTO `migrations` VALUES ('62', '2024_01_01_000001_create_gurus_table', '1');
INSERT INTO `migrations` VALUES ('63', '2024_01_01_000002_create_kelas_table', '1');
INSERT INTO `migrations` VALUES ('64', '2024_01_01_000003_create_siswas_table', '1');
INSERT INTO `migrations` VALUES ('65', '2024_01_01_000005_create_jenis_pelanggarans_table', '1');
INSERT INTO `migrations` VALUES ('66', '2024_01_01_000006_create_pelanggarans_table', '1');
INSERT INTO `migrations` VALUES ('67', '2024_01_01_000007_create_sanksis_table', '1');
INSERT INTO `migrations` VALUES ('68', '2024_01_01_000008_create_pelaksanaan_sanksis_table', '1');
INSERT INTO `migrations` VALUES ('69', '2024_01_01_000009_create_jenis_prestasis_table', '1');
INSERT INTO `migrations` VALUES ('70', '2024_01_01_000010_create_prestasis_table', '1');
INSERT INTO `migrations` VALUES ('71', '2024_01_01_000011_create_bimbingan_konselings_table', '1');
INSERT INTO `migrations` VALUES ('72', '2024_01_01_000012_create_monitoring_pelanggarans_table', '1');
INSERT INTO `migrations` VALUES ('73', '2024_01_01_000013_create_verifikasi_datas_table', '1');
INSERT INTO `migrations` VALUES ('74', '2024_01_20_000001_create_biodata_ortus_table', '1');
INSERT INTO `migrations` VALUES ('75', '2024_01_21_000001_create_komunikasi_ortus_table', '1');
INSERT INTO `migrations` VALUES ('76', '2025_01_07_create_notifications_table', '1');
INSERT INTO `migrations` VALUES ('77', '2025_01_20_000000_add_metadata_to_users_table', '1');
INSERT INTO `migrations` VALUES ('78', '2025_01_20_000001_add_verifikator_role_to_users', '1');
INSERT INTO `migrations` VALUES ('79', '2025_11_13_094337_create_personal_access_tokens_table', '1');
INSERT INTO `migrations` VALUES ('80', '2025_11_18_073631_create_permission_tables', '1');
INSERT INTO `migrations` VALUES ('81', '2025_11_19_010020_add_bidang_studi_status_to_gurus_table', '1');
INSERT INTO `migrations` VALUES ('82', '2025_11_19_013203_add_kategori_to_jenis_pelanggarans_table', '1');
INSERT INTO `migrations` VALUES ('83', '2025_11_19_014335_add_kelompok_to_jenis_pelanggarans_table', '1');
INSERT INTO `migrations` VALUES ('84', '2025_11_19_024551_add_tingkat_kelompok_to_jenis_prestasis_table', '1');
INSERT INTO `migrations` VALUES ('85', '2025_11_19_100000_add_poin_to_prestasis_table', '1');
INSERT INTO `migrations` VALUES ('86', '2025_11_20_000001_create_password_reset_tokens_table', '1');
INSERT INTO `migrations` VALUES ('87', '2025_11_20_062614_create_password_resets_table', '1');
INSERT INTO `migrations` VALUES ('88', '2025_11_25_055758_add_verification_to_users_table', '1');
INSERT INTO `migrations` VALUES ('89', '2025_11_25_083206_add_tanggal_pelanggaran_to_pelanggarans_table', '1');
INSERT INTO `migrations` VALUES ('90', '2025_11_25_084946_add_missing_columns_to_prestasis_table', '1');
INSERT INTO `migrations` VALUES ('91', '2026_01_05_112314_add_status_approval_to_gurus_table', '1');
INSERT INTO `migrations` VALUES ('92', '2026_01_05_123342_update_tahun_ajarans_table_remove_tahun_ajaran_add_approval', '1');
INSERT INTO `migrations` VALUES ('93', '2026_01_05_154148_add_status_approval_to_kelas_table', '1');
INSERT INTO `migrations` VALUES ('94', '2026_01_05_160637_add_jenis_kelamin_to_gurus_table', '1');
INSERT INTO `migrations` VALUES ('95', '2026_01_06_013315_add_jenis_kelamin_to_gurus_table', '1');
INSERT INTO `migrations` VALUES ('96', '2026_01_06_015920_add_last_login_to_users_table', '1');
INSERT INTO `migrations` VALUES ('97', '2026_01_06_025020_add_status_approval_to_siswas_table', '1');
INSERT INTO `migrations` VALUES ('98', '2026_01_06_063147_add_kategori_to_bimbingan_konselings_table', '1');
INSERT INTO `migrations` VALUES ('99', '2026_01_06_115508_add_pelanggaran_list_to_pelanggarans_table', '1');
INSERT INTO `migrations` VALUES ('100', '2026_01_06_144417_add_auto_sanksi_fields_to_sanksis_table', '1');
INSERT INTO `migrations` VALUES ('101', '2026_01_06_161525_add_prestasi_list_to_prestasis_table', '1');
INSERT INTO `migrations` VALUES ('102', '2026_01_07_051852_create_sent_notifications_table', '1');
INSERT INTO `migrations` VALUES ('103', '2026_01_07_121636_add_biodata_to_users_table', '1');
INSERT INTO `migrations` VALUES ('104', '2026_01_08_000001_add_wali_kelas_fields_to_users_table', '1');
INSERT INTO `migrations` VALUES ('105', '2026_01_08_100000_create_class_homeroom_teachers_table', '1');
INSERT INTO `migrations` VALUES ('106', '2026_01_08_110000_add_dual_role_approval_to_users_table', '1');
INSERT INTO `migrations` VALUES ('107', '2026_01_11_203341_add_child_info_to_users_table', '1');
INSERT INTO `migrations` VALUES ('108', '2026_01_12_025932_remove_status_approval_from_kelas_table', '1');
INSERT INTO `migrations` VALUES ('109', '2026_01_12_034553_add_mata_pelajaran_to_gurus_table', '1');
INSERT INTO `migrations` VALUES ('110', '2026_01_12_071909_add_alamat_and_foto_ktp_to_biodata_ortus_table', '1');
INSERT INTO `migrations` VALUES ('111', '2026_01_12_072547_remove_foto_ktp_from_biodata_ortus_table', '1');
INSERT INTO `migrations` VALUES ('112', '2026_01_12_081813_add_no_telp_and_foto_to_users_table', '1');
INSERT INTO `migrations` VALUES ('113', '2026_01_12_082717_create_sent_notifications_table_fix', '1');
INSERT INTO `migrations` VALUES ('114', '2026_01_12_083945_create_sessions_table_manual', '1');

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `monitoring_pelanggarans`;
CREATE TABLE `monitoring_pelanggarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pelanggaran_id` bigint(20) unsigned NOT NULL,
  `progres` text DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `monitoring_pelanggarans_pelanggaran_id_foreign` (`pelanggaran_id`),
  CONSTRAINT `monitoring_pelanggarans_pelanggaran_id_foreign` FOREIGN KEY (`pelanggaran_id`) REFERENCES `pelanggarans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notifications` VALUES ('35225a6a-7e68-4c01-a05e-3b6fb0f2f06d', 'App\\Notifications\\SystemNotification', 'App\\Models\\User', '1', '{\"title\":\"TEST\",\"message\":\"xxxx\",\"type\":\"info\",\"action_url\":null,\"action_text\":null,\"created_at\":\"2026-01-12 16:31:25\"}', '2026-01-12 18:53:25', '2026-01-12 16:31:25', '2026-01-12 18:53:25');

DROP TABLE IF EXISTS `panggilan_ortus`;
CREATE TABLE `panggilan_ortus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned NOT NULL,
  `pelanggaran_id` bigint(20) unsigned DEFAULT NULL,
  `dibuat_oleh` bigint(20) unsigned NOT NULL,
  `judul` varchar(255) NOT NULL,
  `keterangan` text NOT NULL,
  `tanggal_panggilan` datetime NOT NULL,
  `tempat` varchar(255) NOT NULL,
  `status` enum('menunggu_konfirmasi','dikonfirmasi','selesai','dibatalkan') NOT NULL DEFAULT 'menunggu_konfirmasi',
  `catatan_hasil` text DEFAULT NULL,
  `dikonfirmasi_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `panggilan_ortus_siswa_id_foreign` (`siswa_id`),
  KEY `panggilan_ortus_pelanggaran_id_foreign` (`pelanggaran_id`),
  KEY `panggilan_ortus_dibuat_oleh_foreign` (`dibuat_oleh`),
  CONSTRAINT `panggilan_ortus_dibuat_oleh_foreign` FOREIGN KEY (`dibuat_oleh`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `panggilan_ortus_pelanggaran_id_foreign` FOREIGN KEY (`pelanggaran_id`) REFERENCES `pelanggarans` (`id`) ON DELETE SET NULL,
  CONSTRAINT `panggilan_ortus_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_reset_tokens_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `pelaksanaan_sanksis`;
CREATE TABLE `pelaksanaan_sanksis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sanksi_id` bigint(20) unsigned NOT NULL,
  `tanggal_pelaksanaan` date NOT NULL,
  `keterangan` text DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pelaksanaan_sanksis_sanksi_id_foreign` (`sanksi_id`),
  CONSTRAINT `pelaksanaan_sanksis_sanksi_id_foreign` FOREIGN KEY (`sanksi_id`) REFERENCES `sanksis` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `pelanggarans`;
CREATE TABLE `pelanggarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned NOT NULL,
  `guru_pencatat` bigint(20) unsigned NOT NULL,
  `jenis_pelanggaran_id` bigint(20) unsigned NOT NULL,
  `tahun_ajaran_id` bigint(20) unsigned NOT NULL,
  `poin` int(11) NOT NULL,
  `tanggal_pelanggaran` date DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `pelanggaran_list` text DEFAULT NULL,
  `status_verifikasi` enum('menunggu','diverifikasi','ditolak') NOT NULL DEFAULT 'menunggu',
  `guru_verifikator` bigint(20) unsigned DEFAULT NULL,
  `tanggal_verifikasi` timestamp NULL DEFAULT NULL,
  `alasan_penolakan` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pelanggarans_siswa_id_foreign` (`siswa_id`),
  KEY `pelanggarans_guru_pencatat_foreign` (`guru_pencatat`),
  KEY `pelanggarans_jenis_pelanggaran_id_foreign` (`jenis_pelanggaran_id`),
  KEY `pelanggarans_tahun_ajaran_id_foreign` (`tahun_ajaran_id`),
  KEY `pelanggarans_guru_verifikator_foreign` (`guru_verifikator`),
  CONSTRAINT `pelanggarans_guru_pencatat_foreign` FOREIGN KEY (`guru_pencatat`) REFERENCES `gurus` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pelanggarans_guru_verifikator_foreign` FOREIGN KEY (`guru_verifikator`) REFERENCES `gurus` (`id`) ON DELETE SET NULL,
  CONSTRAINT `pelanggarans_jenis_pelanggaran_id_foreign` FOREIGN KEY (`jenis_pelanggaran_id`) REFERENCES `jenis_pelanggarans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pelanggarans_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pelanggarans_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajarans` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `pelanggarans` VALUES ('1', '1', '3', '9', '2', '10', '2026-01-12', 'gvg', NULL, 'diverifikasi', NULL, '2026-01-12 17:27:16', NULL, '2026-01-12 17:27:11', '2026-01-12 17:27:16');

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` text NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `prestasis`;
CREATE TABLE `prestasis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `siswa_id` bigint(20) unsigned NOT NULL,
  `guru_pencatat` bigint(20) unsigned DEFAULT NULL,
  `jenis_prestasi_id` bigint(20) unsigned NOT NULL,
  `tahun_ajaran_id` bigint(20) unsigned DEFAULT NULL,
  `poin` int(11) NOT NULL DEFAULT 0,
  `prestasi_list` text DEFAULT NULL,
  `tanggal_prestasi` date DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  `status_verifikasi` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  `guru_verifikator` bigint(20) unsigned DEFAULT NULL,
  `tanggal_verifikasi` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prestasis_siswa_id_foreign` (`siswa_id`),
  KEY `prestasis_jenis_prestasi_id_foreign` (`jenis_prestasi_id`),
  KEY `prestasis_guru_pencatat_foreign` (`guru_pencatat`),
  KEY `prestasis_tahun_ajaran_id_foreign` (`tahun_ajaran_id`),
  KEY `prestasis_guru_verifikator_foreign` (`guru_verifikator`),
  CONSTRAINT `prestasis_guru_pencatat_foreign` FOREIGN KEY (`guru_pencatat`) REFERENCES `gurus` (`id`) ON DELETE SET NULL,
  CONSTRAINT `prestasis_guru_verifikator_foreign` FOREIGN KEY (`guru_verifikator`) REFERENCES `gurus` (`id`) ON DELETE SET NULL,
  CONSTRAINT `prestasis_jenis_prestasi_id_foreign` FOREIGN KEY (`jenis_prestasi_id`) REFERENCES `jenis_prestasis` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prestasis_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prestasis_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajarans` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sanksis`;
CREATE TABLE `sanksis` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pelanggaran_id` bigint(20) unsigned NOT NULL,
  `siswa_id` bigint(20) unsigned DEFAULT NULL,
  `nama_sanksi` varchar(255) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL,
  `status_sanksi` varchar(255) NOT NULL,
  `kategori_poin` varchar(255) DEFAULT NULL,
  `total_poin` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sanksis_pelanggaran_id_foreign` (`pelanggaran_id`),
  KEY `sanksis_siswa_id_foreign` (`siswa_id`),
  CONSTRAINT `sanksis_pelanggaran_id_foreign` FOREIGN KEY (`pelanggaran_id`) REFERENCES `pelanggarans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `sanksis_siswa_id_foreign` FOREIGN KEY (`siswa_id`) REFERENCES `siswas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `sent_notifications`;
CREATE TABLE `sent_notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `type` varchar(255) NOT NULL,
  `target_type` varchar(255) NOT NULL,
  `target_value` varchar(255) NOT NULL,
  `recipients_count` int(11) NOT NULL,
  `action_url` varchar(255) DEFAULT NULL,
  `sent_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sent_notifications_sent_by_foreign` (`sent_by`),
  CONSTRAINT `sent_notifications_sent_by_foreign` FOREIGN KEY (`sent_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sent_notifications` VALUES ('1', 'TEST', 'xxxx', 'info', 'role', 'all', '1', NULL, '1', '2026-01-12 16:31:25', '2026-01-12 16:31:25');

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` VALUES ('Bi2IUXbEUv7KpvMPwmfNFHgShSlR1mB1BcV2rUSs', '1', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoib2xlbkVUN1IydUF2d0NTWWp5dzJiaFBHVlA4SUNYZkRoVE1tbXFYNSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6Mjg6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9iYWNrdXAiO3M6NToicm91dGUiO3M6MTI6ImJhY2t1cC5pbmRleCI7fXM6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjE7fQ==', '1768267253');
INSERT INTO `sessions` VALUES ('D5M8dMztdFH4IURU8qoLE4aU3sQ9kKIS3nS6zl17', '6', '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiTThxalc4WlhJRlpkUEVSakpjcDd6Sk1NQlZYU3JWRVd4YzBHVkVTQiI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjM0OiJodHRwOi8vbG9jYWxob3N0OjgwMDAvcmVmcmVzaC1jc3JmIjtzOjU6InJvdXRlIjtzOjI3OiJnZW5lcmF0ZWQ6Ok5FdnowOWlzR2NFa2VTV2YiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTo2O30=', '1768264529');
INSERT INTO `sessions` VALUES ('dWTXoV1Ua8P6pimRwpi0hKeh7TtipF2qhNr3rUxf', '1', '127.0.0.1', 'Symfony', 'YTo0OntzOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6NjoiX3Rva2VuIjtzOjQwOiJZU2RVMWdHelJ4Z0FaRERuZkM0TFBYZkhEMHJtbkdqTHFjRFo3YXRZIjtzOjk6Il9wcmV2aW91cyI7YToyOntzOjM6InVybCI7czoyMjoiaHR0cDovL2xvY2FsaG9zdC9zaXN3YSI7czo1OiJyb3V0ZSI7czoxMToic2lzd2EuaW5kZXgiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', '1768240237');

DROP TABLE IF EXISTS `siswas`;
CREATE TABLE `siswas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `users_id` bigint(20) unsigned DEFAULT NULL,
  `nis` varchar(20) NOT NULL,
  `nama_siswa` varchar(255) NOT NULL,
  `kelas_id` bigint(20) unsigned NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `tahun_ajaran_id` bigint(20) unsigned NOT NULL,
  `status_approval` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `siswas_nis_unique` (`nis`),
  KEY `siswas_users_id_foreign` (`users_id`),
  KEY `siswas_kelas_id_foreign` (`kelas_id`),
  KEY `siswas_tahun_ajaran_id_foreign` (`tahun_ajaran_id`),
  CONSTRAINT `siswas_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `siswas_tahun_ajaran_id_foreign` FOREIGN KEY (`tahun_ajaran_id`) REFERENCES `tahun_ajarans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `siswas_users_id_foreign` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `siswas` VALUES ('1', '13', '2024001', 'Andi Wijaya', '1', 'L', '2', 'pending', '2026-01-12 16:58:09', '2026-01-12 16:58:09');
INSERT INTO `siswas` VALUES ('2', '14', '2024002', 'Siti Nurhaliza', '2', 'P', '2', 'pending', '2026-01-12 16:58:10', '2026-01-12 16:58:10');
INSERT INTO `siswas` VALUES ('3', '15', '2024003', 'Budi Setiawan', '3', 'L', '2', 'pending', '2026-01-12 16:58:11', '2026-01-12 16:58:11');
INSERT INTO `siswas` VALUES ('4', '16', '2024004', 'Dewi Sartika', '4', 'P', '2', 'pending', '2026-01-12 16:58:12', '2026-01-12 16:58:12');
INSERT INTO `siswas` VALUES ('5', '17', '2024005', 'Rizki Pratama', '5', 'L', '2', 'pending', '2026-01-12 16:58:12', '2026-01-12 16:58:12');
INSERT INTO `siswas` VALUES ('6', '18', '2024006', 'Fitri Handayani', '6', 'P', '2', 'pending', '2026-01-12 16:58:13', '2026-01-12 16:58:13');
INSERT INTO `siswas` VALUES ('7', '19', '2024007', 'Doni Saputra', '7', 'L', '2', 'pending', '2026-01-12 16:58:14', '2026-01-12 16:58:14');
INSERT INTO `siswas` VALUES ('8', '20', '2024008', 'Rina Wati', '8', 'P', '2', 'pending', '2026-01-12 16:58:15', '2026-01-12 16:58:15');
INSERT INTO `siswas` VALUES ('9', '7', '20240007', 'fardhan revano arifqi', '1', 'L', '2', 'approved', '2026-01-12 17:18:51', '2026-01-12 17:18:51');

DROP TABLE IF EXISTS `tahun_ajarans`;
CREATE TABLE `tahun_ajarans` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tahun_mulai` year(4) NOT NULL,
  `tahun_selesai` year(4) NOT NULL,
  `semester` enum('ganjil','genap') NOT NULL,
  `status_aktif` enum('aktif','nonaktif') NOT NULL DEFAULT 'nonaktif',
  `status_approval` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `tahun_ajarans` VALUES ('1', '2023', '2024', 'ganjil', 'nonaktif', 'pending', '2026-01-12 16:41:11', '2026-01-12 16:41:11');
INSERT INTO `tahun_ajarans` VALUES ('2', '2024', '2025', 'ganjil', 'aktif', 'pending', '2026-01-12 16:41:11', '2026-01-12 16:41:11');
INSERT INTO `tahun_ajarans` VALUES ('3', '2025', '2026', 'ganjil', 'nonaktif', 'pending', '2026-01-12 16:41:13', '2026-01-12 16:41:13');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) NOT NULL,
  `nik` varchar(255) DEFAULT NULL,
  `no_hp` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `pekerjaan` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `no_telp` varchar(20) DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','kesiswaan','guru','wali_kelas','siswa','ortu','bk','kepala_sekolah','verifikator') DEFAULT NULL,
  `allow_dual_role` tinyint(1) NOT NULL DEFAULT 0,
  `additional_roles` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_roles`)),
  `is_wali_kelas` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `biodata_completed` tinyint(1) NOT NULL DEFAULT 0,
  `verified_by` bigint(20) unsigned DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `nama_anak` varchar(255) DEFAULT NULL,
  `nis_anak` varchar(255) DEFAULT NULL,
  `metadata` text DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `last_activity_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `kelas_id` bigint(20) unsigned DEFAULT NULL,
  `dual_role_approved_by` bigint(20) unsigned DEFAULT NULL,
  `dual_role_approved_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  KEY `users_verified_by_foreign` (`verified_by`),
  KEY `users_kelas_id_foreign` (`kelas_id`),
  KEY `users_dual_role_approved_by_foreign` (`dual_role_approved_by`),
  CONSTRAINT `users_dual_role_approved_by_foreign` FOREIGN KEY (`dual_role_approved_by`) REFERENCES `users` (`id`),
  CONSTRAINT `users_kelas_id_foreign` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` VALUES ('1', 'Admin System', NULL, NULL, NULL, NULL, 'admin@test.com', NULL, NULL, '$2y$12$yuolEfDSkAgIGc99ENACleMoX0aeIKZHeITNv2wW8bIB6EMq4z5q6', 'admin', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 16:27:33', NULL, '2026-01-13 01:20:23', '2026-01-13 01:20:23', '2026-01-12 16:27:34', '2026-01-13 01:20:23', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('2', 'Neni Rohaeni', NULL, NULL, NULL, NULL, 'neni@gmail.com', NULL, NULL, '$2y$12$4DqGvlmQjqZR7fwvMio6r.9OhDVzvNcA5CbcdrIVYO7m1erlWBr5C', 'kepala_sekolah', '0', NULL, '0', 'approved', '0', '1', '2026-01-12 16:32:24', NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:32:15', '2026-01-12 17:47:06', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('3', 'susilo', NULL, NULL, NULL, NULL, 'susilo@gmail.com', NULL, NULL, '$2y$12$CCjKtFRdHcYmrbHZ7xUKeekxtLFjSZjaPkIdt1qUj5Te3gByK9ZKO', 'kesiswaan', '1', '[\"guru\"]', '0', 'approved', '0', '1', '2026-01-12 16:33:16', NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:33:08', '2026-01-12 17:47:06', NULL, '1', '2026-01-12 16:37:08');
INSERT INTO `users` VALUES ('4', 'Randy orton', NULL, NULL, NULL, NULL, 'randy@gmailt.com', NULL, NULL, '$2y$12$86iG3/Uww.yIVUuOR7zZx.gzlY.MnQmGBTEGZDcPZ6kEZ0qdanj/G', 'bk', '0', NULL, '1', 'approved', '0', '1', '2026-01-12 16:34:02', NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:33:54', '2026-01-12 17:47:06', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('5', 'Diallo caranstias', NULL, NULL, NULL, NULL, 'diallo@gmail.com', NULL, NULL, '$2y$12$ejqqm2m/LJsUPZ6YmKNMLe2dOY2QCNC0Jvx9swbXn64SjTzRB4X/O', 'guru', '0', NULL, '1', 'approved', '0', '1', '2026-01-12 16:34:46', NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:34:38', '2026-01-12 17:47:06', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('6', 'jamaludin', NULL, NULL, NULL, NULL, 'jamal@gmail.com', NULL, NULL, '$2y$12$R.ctOG1tY4KU5JILyjsv0uzsxrnD49NprkfDlZWT2YJhiSyrRnqP2', 'ortu', '0', NULL, '0', 'approved', '0', '1', '2026-01-12 16:35:29', NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', '2CRMmyQKB0y0ZmZUVPbwsPr6BVjTl3J60okYTLZoDkQYarvVMKRAIPmpbvUm', '2026-01-12 17:28:16', '2026-01-12 17:28:16', '2026-01-12 16:35:22', '2026-01-12 17:47:06', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('7', 'fardhan revano arifqi', NULL, NULL, NULL, NULL, 'fardhan@gmail.com', NULL, NULL, '$2y$12$AT9YPmDHYGKcaPsNE8c1Au6XopnPRrdywkDuyuYzhRxWPDmgh8S8K', 'siswa', '0', NULL, '0', 'approved', '0', '1', '2026-01-12 16:36:30', NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:36:21', '2026-01-12 17:47:06', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('8', 'Budi Santoso', NULL, NULL, NULL, NULL, 'budisantoso@guru.test', NULL, NULL, '$2y$12$BdcG8/5WeXCSKMPvRIEik.MHr/.WJ/FLsooB/2JCieJZZwPp4xxTC', 'guru', '0', NULL, '1', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:57:55', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('9', 'Siti Aminah', NULL, NULL, NULL, NULL, 'sitiaminah@guru.test', NULL, NULL, '$2y$12$vJucGf4870x9Q9cMMEISP.AK5OHo0wjpEKb/3XKueB0/AU5BnBmTe', 'guru', '0', NULL, '1', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:57:56', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('10', 'Ahmad Fauzi', NULL, NULL, NULL, NULL, 'ahmadfauzi@guru.test', NULL, NULL, '$2y$12$2xnCUWEc6SU58capn/o8DeCJuZLUPVIovPTQYjhVxxKnNjU.fqMQS', 'guru', '0', NULL, '1', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:57:56', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('11', 'Dewi Lestari', NULL, NULL, NULL, NULL, 'dewilestari@guru.test', NULL, NULL, '$2y$12$roFbnja.9ljjFA3ltNqv/OyvsNZvY1EmUP3D5piIcWQxnSrEJmATy', 'guru', '0', NULL, '1', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:57:57', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('12', 'Rizki Ramadhan', NULL, NULL, NULL, NULL, 'rizkiramadhan@guru.test', NULL, NULL, '$2y$12$Fc1jb/HJPSDJJlg3LX2.2uac0vpsT1OzWxOIeGj29O4v.8JAx5ktK', 'guru', '0', NULL, '1', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:57:58', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('13', 'Andi Wijaya', NULL, NULL, NULL, NULL, 'andiwijaya@siswa.test', NULL, NULL, '$2y$12$XFVQToLODBjDm3eGekIZDOh/hmxyJObJ5vDEc2pyErQ1qHn.l3Da6', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:09', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('14', 'Siti Nurhaliza', NULL, NULL, NULL, NULL, 'sitinurhaliza@siswa.test', NULL, NULL, '$2y$12$ghUKxaIdcrRyp3gq/P48i.b/1k13WyNwtVhl9Qgu7SaMFxhS7tGv.', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:10', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('15', 'Budi Setiawan', NULL, NULL, NULL, NULL, 'budisetiawan@siswa.test', NULL, NULL, '$2y$12$G7SKKvg8PCsH/c5/fNq32efX5ajsU6zUhIBnmQiVAo5TK.klf6XV2', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:11', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('16', 'Dewi Sartika', NULL, NULL, NULL, NULL, 'dewisartika@siswa.test', NULL, NULL, '$2y$12$qhOoOPQLXctN1jI8jBjbUu0JE2NEA9AO4Qh3CT1B.ww3rQ33MIQHq', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:11', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('17', 'Rizki Pratama', NULL, NULL, NULL, NULL, 'rizkipratama@siswa.test', NULL, NULL, '$2y$12$bMbkXlEVw.JmanX3GD7doOws17HLojohlKpRylbP06HoxFYpToIBq', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:12', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('18', 'Fitri Handayani', NULL, NULL, NULL, NULL, 'fitrihandayani@siswa.test', NULL, NULL, '$2y$12$NcOuvrmkH0yu5RO6E7dnU..c4lD4QR2X3urFhOsnH4WwORYraZFia', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:13', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('19', 'Doni Saputra', NULL, NULL, NULL, NULL, 'donisaputra@siswa.test', NULL, NULL, '$2y$12$bME0QvbHTp0o9FSJMe4gheqnbyYN7FaE2InCs2Q4kHpc6Rv97BK82', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:14', '2026-01-12 17:48:03', NULL, NULL, NULL);
INSERT INTO `users` VALUES ('20', 'Rina Wati', NULL, NULL, NULL, NULL, 'rinawati@siswa.test', NULL, NULL, '$2y$12$EFmG6tT3dRZGAZQdd04N6.r94gsIewNL.HddLVrobFIQx7qNiYMZO', 'siswa', '0', NULL, '0', 'approved', '0', NULL, NULL, NULL, NULL, NULL, NULL, '2026-01-12 17:47:06', NULL, NULL, NULL, '2026-01-12 16:58:15', '2026-01-12 17:48:03', NULL, NULL, NULL);

DROP TABLE IF EXISTS `verifikasi_datas`;
CREATE TABLE `verifikasi_datas` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `status` varchar(255) NOT NULL,
  `tanggal` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `verifikasi_datas_user_id_foreign` (`user_id`),
  CONSTRAINT `verifikasi_datas_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

